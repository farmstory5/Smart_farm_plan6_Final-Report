# exec.py
from mylib import *
 
i = add(10,20)
print("add i = ",i)
i = substract(20,5)
print("sub i = ", i)