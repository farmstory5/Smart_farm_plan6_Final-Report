# from class_test import Rectangle
#import class_test
from class_test import Rectangle

r1 = Rectangle(4,4)
r2 = Rectangle(5,5)
r2.printCount()


