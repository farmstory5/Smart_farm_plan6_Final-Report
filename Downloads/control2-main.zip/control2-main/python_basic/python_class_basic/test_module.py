# import math
# n = math.factorial(5)
# print(n)

# from math import factorial  
 
# n = factorial(5) / factorial(3) 
# print(n)

from math import factorial as f
n = f(5) / f(3)
print(n)